module.exports = {
  extends: ["next/core-web-vitals"],
  rules: {
    // Add any custom ESLint rules here
  },
}
